create function insertku(_id integer, _etc character varying) returns void
    language plpgsql
as
$$
BEGIN
        INSERT INTO coba(id, etc)
        VALUES(_id, _etc);
      END;
$$;

alter function insertku(integer, varchar) owner to sofco;


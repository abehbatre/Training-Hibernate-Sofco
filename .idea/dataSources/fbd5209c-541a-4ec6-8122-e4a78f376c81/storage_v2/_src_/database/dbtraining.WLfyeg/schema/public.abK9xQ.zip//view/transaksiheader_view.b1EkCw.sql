create view transaksiheader_view(nomorbon, tanggalbon, bagian, keterangan, kodebarang) as
SELECT h.nomor_bon AS nomorbon, h.tanggal_bon AS tanggalbon, h.bagian, h.keterangan, d.kode_barang AS kodebarang
FROM (adit_master_transaksi_header h
         JOIN adit_master_transaksi_detail d ON ((h.nomor_bon = d.nomor_bon)));

alter table transaksiheader_view
    owner to sofco;


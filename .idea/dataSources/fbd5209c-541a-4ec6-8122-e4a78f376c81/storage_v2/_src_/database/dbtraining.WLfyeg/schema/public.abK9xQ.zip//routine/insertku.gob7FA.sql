create function insertku(_id integer, _etc integer) returns void
    language plpgsql
as
$$
BEGIN
        INSERT INTO coba(id, etc)
        VALUES(_id, _etc);
      END;
$$;

alter function insertku(integer, integer) owner to sofco;

